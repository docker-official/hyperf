<?php

2->test();
